plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.screenassist"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.screenassist"
        minSdk = 29
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("com.google.mlkit:object-detection:17.0.2")
}
