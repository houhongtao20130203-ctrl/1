package com.example.screenassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

data class TargetMark(val x: Float, val y: Float, val expiresAt: Long)

class OverlayView(context: Context) : View(context) {
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(210, 80, 220, 255)
        strokeWidth = 2.5f
        style = Paint.Style.STROKE
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 80, 220, 255)
        style = Paint.Style.FILL
    }

    @Volatile var marks: List<TargetMark> = emptyList()
        set(value) {
            field = value
            postInvalidate()
        }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.currentTimeMillis()
        val live = marks.filter { it.expiresAt > now }
        val originX = width / 2f
        val originY = height * 0.92f
        live.forEach { mark ->
            canvas.drawLine(originX, originY, mark.x, mark.y, linePaint)
            canvas.drawCircle(mark.x, mark.y, 3.5f, dotPaint)
        }
        if (live.size != marks.size) marks = live
    }
}
