package com.example.screenassist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        private const val CHANNEL_ID = "screen_assist"
        private const val NOTIFICATION_ID = 41
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayView? = null
    private var windowManager: WindowManager? = null
    private var workerThread: HandlerThread? = null
    private var worker: Handler? = null
    private val processing = AtomicBoolean(false)
    private var screenWidth = 1
    private var screenHeight = 1
    private var lastAcceptedAt = 0L

    private val detector by lazy {
        val options = ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
            .enableClassification()
            .build()
        ObjectDetection.getClient(options)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        createNotificationChannel()
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("屏幕可见目标辅助正在运行")
            .setContentText("屏幕捕获已启用；点应用中的停止按钮结束。")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startCapture(resultCode, data)
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels

        workerThread = HandlerThread("screen-assist-worker").also { it.start() }
        worker = Handler(workerThread!!.looper)

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = OverlayView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        windowManager?.addView(overlay, params)

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)

        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, worker)

        virtualDisplay = projection?.createVirtualDisplay(
            "ScreenAssistCapture", screenWidth, screenHeight, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, worker
        )

        reader?.setOnImageAvailableListener({ imageReader ->
            val image = imageReader.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (!processing.compareAndSet(false, true)) {
                image.close()
                return@setOnImageAvailableListener
            }
            processImage(image)
        }, worker)
    }

    private fun processImage(image: Image) {
        val now = System.currentTimeMillis()
        // Limit processing rate to reduce battery and heat.
        if (now - lastAcceptedAt < 250) {
            image.close()
            processing.set(false)
            return
        }
        lastAcceptedAt = now
        try {
            val plane = image.planes[0]
            val bitmap = android.graphics.Bitmap.createBitmap(
                image.width, image.height, android.graphics.Bitmap.Config.ARGB_8888
            )
            val buffer = plane.buffer
            bitmap.copyPixelsFromBuffer(buffer)
            val input = InputImage.fromBitmap(bitmap, 0)
            detector.process(input)
                .addOnSuccessListener { objects ->
                    val nowMs = System.currentTimeMillis()
                    val next = objects.mapNotNull { obj ->
                        val person = obj.labels.any {
                            it.text.equals("person", ignoreCase = true)
                        }
                        val box = obj.boundingBox
                        // This is a screen-size heuristic, NOT a true distance measurement.
                        // Ignore tiny boxes and very large close-up boxes.
                        val fraction = box.height().toFloat() / screenHeight.toFloat()
                        if (person && fraction in 0.025f..0.22f) {
                            TargetMark(
                                x = box.exactCenterX(),
                                y = box.top.toFloat(),
                                expiresAt = nowMs + 1500L
                            )
                        } else null
                    }
                    overlay?.marks = next
                }
                .addOnFailureListener {
                    // Keep the overlay empty if recognition fails.
                    overlay?.marks = emptyList()
                }
                .addOnCompleteListener {
                    bitmap.recycle()
                    image.close()
                    processing.set(false)
                }
        } catch (_: Exception) {
            image.close()
            processing.set(false)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "屏幕辅助服务", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        try { reader?.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
        virtualDisplay?.release()
        reader?.close()
        projection?.stop()
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        workerThread?.quitSafely()
        detector.close()
        super.onDestroy()
    }
}
