package com.example.screenassist

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val captureRequest = 701

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        val title = TextView(this).apply {
            text = "屏幕可见目标辅助（原型）"
            textSize = 22f
        }
        val note = TextView(this).apply {
            text = "只处理授权捕获到的屏幕画面。识别结果可能误报或漏报；请先在非对局画面测试。"
            textSize = 15f
            setPadding(0, 20, 0, 24)
        }
        val overlayButton = Button(this).apply {
            text = "第 1 步：开启悬浮窗权限"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                }
            }
        }
        val startButton = Button(this).apply {
            text = "第 2 步：授权屏幕捕获并开始"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    note.text = "请先开启悬浮窗权限，然后再开始。"
                    return@setOnClickListener
                }
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
            }
        }
        val stopButton = Button(this).apply {
            text = "停止辅助"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
            }
        }
        layout.addView(title)
        layout.addView(note)
        layout.addView(overlayButton, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(startButton, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(stopButton, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android API; kept for simple starter compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_DATA, data)
            }
            startForegroundService(serviceIntent)
        }
    }
}
