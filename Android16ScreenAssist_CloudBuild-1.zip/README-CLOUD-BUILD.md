# 用手机浏览器云端编译 APK

## 重要说明
这是用于尝试云端构建的 Android Studio 工程。云端构建成功后会提供 debug APK；此原型未经真实设备完整验证，且 ML Kit 通用物体检测不保证能识别游戏画面中的人物。不要将它视为已验证成品。

## 手机操作概览
1. 在手机浏览器打开 GitHub 并登录/注册账号。
2. 创建一个新的空仓库，建议命名 `Android16ScreenAssist`，选择 Public 或 Private 均可。
3. 将此压缩包解压后，把项目里的文件和文件夹上传到仓库根目录。必须包含 `.github/workflows/build-apk.yml`；手机网页如果隐藏了 `.github` 文件夹，需要切换到桌面版网站或用 GitHub 网页的 Add file 功能逐层创建。
4. 上传并提交到 `main` 分支后，打开仓库的 Actions 页面，进入 `Build Android APK` 工作流。
5. 等待运行结束。绿色成功后，打开该次运行页面底部的 Artifacts，下载 `screen-assist-debug-apk`，解压后得到 `app-debug.apk`。
6. 在手机上打开 APK 安装。Android 可能会要求允许浏览器安装未知应用。

## 构建可能失败
云端日志会显示具体错误。如果失败，请把 Actions 页面里红色失败步骤的错误文字复制过来，便于修复。
